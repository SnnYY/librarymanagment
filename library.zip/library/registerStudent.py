from tkinter import *
from PIL import ImageTk,Image
from tkinter import messagebox
import pyodbc
from datetime import date
import datetime
today = date.today()
today_return = datetime.date.today()


cnxn = pyodbc.connect(r'Driver=SQL Server;Server=.\SQLEXPRESS;Database=db;Trusted_connection=yes;')
cursor = cnxn.cursor()

def register():
    
    global issueBtn,labelFrame,lb1,inf1,quitBtn,root,Canvas1,status
    
    bid = inf1.get()
    password = inf2.get()

    issueBtn.destroy()
    labelFrame.destroy()
    lb1.destroy()
    inf1.destroy()


    
    registerSql = "INSERT INTO auth (id,password) VALUES ('"+bid+"','"+password+"')"
    print(registerSql)
    try:
        cursor.execute(registerSql)
        cnxn.commit()
        messagebox.showinfo('Success',"Student Registered Successfully")
        root.destroy()
    except:
        messagebox.showinfo("Search Error","The value entered is wrong, Try again")
    
    
    

def registerStudent(): 
    
    global issueBtn,labelFrame,lb1,inf1,inf2,quitBtn,root,Canvas1,status
    
    root = Tk()
    root.title("Library")
    root.minsize(width=400,height=400)
    root.geometry("600x500")
    
    Canvas1 = Canvas(root)
    Canvas1.config(bg="#D6ED17")
    Canvas1.pack(expand=True,fill=BOTH)

    headingFrame1 = Frame(root,bg="#FFBB00",bd=5)
    headingFrame1.place(relx=0.25,rely=0.1,relwidth=0.5,relheight=0.13)
        
    headingLabel = Label(headingFrame1, text="Register Student", bg='black', fg='white', font=('Courier',15))
    headingLabel.place(relx=0,rely=0, relwidth=1, relheight=1)
    
    labelFrame = Frame(root,bg='black')
    labelFrame.place(relx=0.1,rely=0.3,relwidth=0.8,relheight=0.5)  
        
    # Book ID
    lb1 = Label(labelFrame,text="Student ID : ", bg='black', fg='white')
    lb1.place(relx=0.05,rely=0.2)
        
    inf1 = Entry(labelFrame)
    inf1.place(relx=0.3,rely=0.2, relwidth=0.62)

    lb2 = Label(labelFrame,text="Password : ", bg='black', fg='white')
    lb2.place(relx=0.05,rely=0.5)
        
    inf2 = Entry(labelFrame)
    inf2.place(relx=0.3,rely=0.5, relwidth=0.62)
    
    

    #Issue Button
    issueBtn = Button(root,text="Register",bg='#d1ccc0', fg='black',command=register)
    issueBtn.place(relx=0.28,rely=0.9, relwidth=0.18,relheight=0.08)
    
    quitBtn = Button(root,text="Quit",bg='#aaa69d', fg='black', command=root.destroy)
    quitBtn.place(relx=0.53,rely=0.9, relwidth=0.18,relheight=0.08)
    
    root.mainloop()